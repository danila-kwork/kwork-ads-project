package ru.maproject.qrcode.ui.view.camera.model

data class SourceInfo(
    val width: Int,
    val height: Int,
    val isImageFlipped: Boolean
)
