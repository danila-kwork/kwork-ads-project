package ru.maproject.qrcode.ui.view.camera.model

enum class PreviewScaleType {
    FIT_CENTER,
    CENTER_CROP
}